#given file
#!/usr/bin/env python
import sys
base_dir = sys.argv[1]
